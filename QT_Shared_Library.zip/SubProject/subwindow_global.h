#ifndef SUBWINDOW_GLOBAL_H
#define SUBWINDOW_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(SUBWINDOWLIB_LIBRARY)
#  define SUBWINDOWLIB_EXPORT Q_DECL_EXPORT
#else
#  define SUBWINDOWLIB_EXPORT Q_DECL_IMPORT
#endif


#endif // SUBWINDOW_GLOBAL_H
